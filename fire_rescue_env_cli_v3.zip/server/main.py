#!/usr/bin/env python3
import argparse, asyncio, json, yaml, sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[1]))
from env.generate_random_scene import generate_random_scene

async def serve_forever(host:str, port:int, payload:dict):
    import websockets
    async def handler(ws):
        await ws.send(json.dumps(payload))
        try:
            async for msg in ws:
                print("[Unity->Python]", msg)
        except Exception:
            pass
    async with websockets.serve(handler, host, port):
        print(f"🟢 Server UP on ws://{host}:{port} (Ctrl+C to stop)")
        await asyncio.Future()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--host', default='0.0.0.0'); ap.add_argument('--port', type=int, default=8765); ap.add_argument('--seed', type=int, default=None)
    args = ap.parse_args()
    spec_path = Path(__file__).resolve().parents[1] / 'env' / 'spec.yaml'
    generate_random_scene(str(spec_path), seed=args.seed)
    with open(spec_path,'r') as f: world_spec = yaml.safe_load(f)
    candidates = [
        {"action":"move_forward","robot":"robot1","target":""},
        {"action":"move_back","robot":"robot1","target":""},
        {"action":"move_left","robot":"robot1","target":""},
        {"action":"move_right","robot":"robot1","target":""},
        {"action":"pick_extinguisher","robot":"robot1","target":""},
        {"action":"extinguish_fire","robot":"robot1","target":""},
        {"action":"move_forward","robot":"robot2","target":""},
        {"action":"move_back","robot":"robot2","target":""},
        {"action":"move_left","robot":"robot2","target":""},
        {"action":"move_right","robot":"robot2","target":""},
        {"action":"deliver","robot":"robot2","target":"Human3"},
    ]
    payload = {"type":"world_init","world":world_spec,"candidates":candidates,
               "dynamic": world_spec.get('rules',{}).get('dynamic', {"enabled":True,"on_step":True,"fire_spread_seconds":45})}
    asyncio.run(serve_forever(args.host, args.port, payload))

if __name__=='__main__': main()
