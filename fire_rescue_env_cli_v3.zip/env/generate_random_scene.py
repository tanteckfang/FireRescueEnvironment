import random, yaml
def generate_random_scene(path: str, seed: int | None = None):
    random.seed(seed)
    rooms = [{"id": f"Room{i}", "pos": [12*(i%2), 0, 12*(i//2)]} for i in range(1,5)]
    doors = [
        {"between": ["Room1","Room2"]},
        {"between": ["Room1","Room3"]},
        {"between": ["Room2","Room4"]},
        {"between": ["Room3","Room4"]}
    ]
    def choice(): return random.choice(rooms)["id"]
    fires = [{"id": f"Fire{i}", "room": choice()} for i in range(1,5)]
    survivors = [{"id": f"Human{i}", "room": choice()} for i in range(1,4)]
    kits = [{"id": f"Kit{i}", "room": choice()} for i in range(1,4)]
    exts = [{"id": f"Ext{i}", "room": choice(), "capacity": 2} for i in range(1,3)]
    obstacles = []
    for j in range(random.randint(1,3)):
        obstacles.append({
            "id": f"Obstacle{j+1}", "room": choice(),
            "aabb": [[random.uniform(0, 6), 0, random.uniform(0, 6)],
                     [random.uniform(6, 12), 1.0, random.uniform(6, 12)]]
        })
    scene = {"map": {"rooms": rooms, "doors": doors, "obstacles": obstacles},
             "entities": {"fires": fires, "survivors": survivors, "first_aid_kits": kits, "extinguishers": exts},
             "robots": [
                 {"id":"robot1","type":"legged","room":"Room1",
                  "capabilities":["move","pick","drop","extinguish_fire","pick_extinguisher"],
                  "fov_deg":120,"range_m":10,"battery_actions":12},
                 {"id":"robot2","type":"drone","room":"Room1",
                  "capabilities":["move","pick","drop","deliver"],
                  "fov_deg":140,"range_m":14,"battery_actions":16}
             ],
             "rules": {"obstacles_block_nav": True, "partial_observability": True,
                        "dynamic": {"enabled": True, "on_step": True, "fire_spread_seconds": 45}}}
    with open(path, "w") as f: yaml.safe_dump(scene, f, sort_keys=False)
    return path
